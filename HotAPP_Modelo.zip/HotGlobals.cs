﻿global using Hot;
global using Hot.Extensions;

global using static Hot.Functions;
global using static Hot.HotConfiguration.config;
global using static Hot.HotLog.log;
